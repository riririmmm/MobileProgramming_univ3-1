package com.example.project.model;

import java.util.List;

public class KakaoBookResponse {
    public List<BookDocument> documents;
}
