package com.example.project.model;

public class BookDocument {
    public String title;
    public String thumbnail;
    public String datetime;
    public String publisher;
}
