package com.example.project.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project.R;
import com.example.project.SearchAdapter;
import com.example.project.SearchItem;
import com.example.project.api.BookApiService;
import com.example.project.api.CultureEventService;
import com.example.project.api.MovieApiService;
import com.example.project.model.BookDocument;
import com.example.project.model.KakaoBookResponse;
import com.example.project.model.KmdbMovieResponse;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SearchFragment extends Fragment {

    private Spinner spinnerCategory;
    private EditText editSearch;
    private Button btnSearch;
    private RecyclerView recyclerView;

    private final List<SearchItem> searchResults = new ArrayList<>();
    private SearchAdapter searchAdapter;

    private static final String API_KEY = "KakaoAK 36146fd94f8ef0f8e3e39c1c3c3ab9a4";
    private static final String KMDB_API_KEY = "88P9S5241Y6M69G97SE4";
    private static final String CULTURE_API_KEY = "pyMVr%2BULSiFtOQIsRD%2F0zXNqReuQ%2FEKnkRWE9Uv%2FoQ6qfFtKVznzbKcyOkPpWVB5wWqvt0HdUsKFUHxJuag3Zg%3D%3D";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_search, container, false);

        spinnerCategory = view.findViewById(R.id.spinner_category);
        editSearch = view.findViewById(R.id.edit_search);
        btnSearch = view.findViewById(R.id.btn_search);
        recyclerView = view.findViewById(R.id.recycler_search_result);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        searchAdapter = new SearchAdapter(getContext(), searchResults);
        recyclerView.setAdapter(searchAdapter);

        btnSearch.setOnClickListener(v -> {
            String keyword = editSearch.getText().toString();
            String category = spinnerCategory.getSelectedItem().toString();

            if (category.equals("도서")) {
                searchResults.clear();
                searchBooks(keyword);
            } else if (category.equals("영화")) {
                searchResults.clear();
                searchMovies(keyword);
            } else if (category.equals("전시/공연")) {
                searchResults.clear();
                searchCultureEvents(keyword);
            } else {
                Toast.makeText(getContext(), category + " 검색 API는 아직 미구현입니다.", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    private void searchBooks(String keyword) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://dapi.kakao.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BookApiService api = retrofit.create(BookApiService.class);
        Call<KakaoBookResponse> call = api.searchBooks(API_KEY, keyword);

        call.enqueue(new Callback<KakaoBookResponse>() {
            @Override
            public void onResponse(Call<KakaoBookResponse> call, Response<KakaoBookResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<BookDocument> docs = response.body().documents;
                    searchResults.clear();
                    for (BookDocument doc : docs) {
                        searchResults.add(new SearchItem(doc.title, doc.thumbnail));
                    }
                    searchAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(getContext(), "API 응답 오류", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<KakaoBookResponse> call, Throwable t) {
                Toast.makeText(getContext(), "API 요청 실패: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void searchMovies(String keyword) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.koreafilm.or.kr/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        MovieApiService api = retrofit.create(MovieApiService.class);
        Call<KmdbMovieResponse> call = api.searchMovies("kmdb_new2", "Y", KMDB_API_KEY, keyword);

        call.enqueue(new Callback<KmdbMovieResponse>() {
            @Override
            public void onResponse(Call<KmdbMovieResponse> call, Response<KmdbMovieResponse> response) {
                if (response.isSuccessful() && response.body() != null && !response.body().Data.isEmpty()) {
                    List<KmdbMovieResponse.MovieResult> results = response.body().Data.get(0).Result;
                    searchResults.clear();
                    for (KmdbMovieResponse.MovieResult result : results) {
                        String imageUrl = (result.posters != null && result.posters.contains("|"))
                                ? result.posters.split("\\|")[0] : result.posters;
                        if (imageUrl != null && imageUrl.startsWith("http://")) {
                            imageUrl = imageUrl.replaceFirst("http://", "https://");
                        }
                        searchResults.add(new SearchItem(result.title.replaceAll("!HS|!HE", ""), imageUrl));
                    }
                    searchAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(getContext(), "영화 API 응답 없음", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<KmdbMovieResponse> call, Throwable t) {
                Toast.makeText(getContext(), "영화 API 요청 실패: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void searchCultureEvents(String keyword) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://apis.data.go.kr/")
                .addConverterFactory(GsonConverterFactory.create()) // Gson은 안 써도 되고 무시됨
                .build();

        CultureEventService service = retrofit.create(CultureEventService.class);

        Call<ResponseBody> call = service.searchCultureEvents(
                CULTURE_API_KEY,
                1,
                10,
                keyword
        );

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful() && response.body() != null) {
                    try {
                        String xml = response.body().string();
                        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                        DocumentBuilder builder = factory.newDocumentBuilder();
                        InputSource is = new InputSource(new StringReader(xml));
                        Document doc = builder.parse(is);
                        NodeList items = doc.getElementsByTagName("perforList");

                        for (int i = 0; i < items.getLength(); i++) {
                            Element element = (Element) items.item(i);
                            String seq = getTagValue("seq", element);
                            fetchEventDetail(seq);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void fetchEventDetail(String seq) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://apis.data.go.kr/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        CultureEventService service = retrofit.create(CultureEventService.class);

        Call<ResponseBody> call = service.getEventDetail(
                CULTURE_API_KEY,
                seq
        );

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful() && response.body() != null) {
                    try {
                        String xml = response.body().string();
                        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                        DocumentBuilder builder = factory.newDocumentBuilder();
                        InputSource is = new InputSource(new StringReader(xml));
                        Document doc = builder.parse(is);
                        Element element = (Element) doc.getElementsByTagName("perforInfo").item(0);

                        String title = getTagValue("title", element);
                        String place = getTagValue("place", element);
                        String image = getTagValue("imgUrl", element);

                        getActivity().runOnUiThread(() -> {
                            searchResults.add(new SearchItem(title + " @ " + place, image));
                            searchAdapter.notifyDataSetChanged();
                        });

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private String getTagValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag);
        if (nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        }
        return "";
    }

}