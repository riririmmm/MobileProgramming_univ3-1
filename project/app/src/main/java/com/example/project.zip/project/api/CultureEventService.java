package com.example.project.api;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface CultureEventService {
    @GET("B553457/nopenapi/rest/publicperformancedisplays/livelihood?")
    Call<ResponseBody> searchCultureEvents(
            @Query("serviceKey") String serviceKey,
            @Query("PageNo") int pageNo,
            @Query("numOfRows") int numOfRows,
            @Query("keyword") String keyword
    );

    @GET("B553457/nopenapi/rest/publicperformancedisplays/detail?")
    Call<ResponseBody> getEventDetail(
            @Query("serviceKey") String serviceKey,
            @Query("seq") String seq
    );
}

