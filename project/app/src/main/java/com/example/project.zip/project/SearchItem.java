package com.example.project;

public class SearchItem {
    public String title;
    public String imageUrl;

    public SearchItem(String title, String imageUrl) {
        this.title = title;
        this.imageUrl = imageUrl;
    }
}
