package com.example.project.model;

import java.util.List;

public class KmdbMovieResponse {
    public List<MovieData> Data;

    public static class MovieData {
        public List<MovieResult> Result;
    }

    public static class MovieResult {
        public String title;
        public String posters;
    }
}
