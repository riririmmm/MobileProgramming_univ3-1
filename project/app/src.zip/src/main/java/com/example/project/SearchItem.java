package com.example.project;

public class SearchItem {
    public String title;
    public String imageUrl;
    public String desc1;
    public String desc2;
    public String desc3;

    public SearchItem(String title, String imageUrl, String desc1, String desc2, String desc3) {
        this.title = title;
        this.imageUrl = imageUrl;
        this.desc1 = desc1;
        this.desc2 = desc2;
        this.desc3 = desc3;
    }
}
